import Home from "./home";
import OrderManagerDashboard from "./order_manager/dashboard";
import CustomerDashboard from "./customer/dashboard";
import Login from "./login";
import CustomerSignup from "./signup";
import Product from "./product";
import Order from "./order";
import Shop from "./shop";
import ProductDetail from "./product_detail";
import Cart from "./cart";
import Checkout from "./checkout";

export {
  Home,
  Login,
  CustomerSignup,
  OrderManagerDashboard,
  Product,
  Order,
  CustomerDashboard,
  Shop,
  ProductDetail,
  Cart,
  Checkout,
};
