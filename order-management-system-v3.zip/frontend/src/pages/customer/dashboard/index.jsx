import CustomerSidebar from "./CustomerSidebar";
//
const index = () => {
  return (
    <>
      <CustomerSidebar />
    </>
  );
};

export default index;
