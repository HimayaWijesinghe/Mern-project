import OrderManagerSidebar from "./OrderManagerSidebar";
//
const index = () => {
  return (
    <>
      <OrderManagerSidebar />
    </>
  );
};

export default index;
