// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getStorage } from "firebase/storage";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDNUCizcbG280KIf7sK2f9EXlm3zy6MKi8",
  authDomain: "order-management-system-fc3bf.firebaseapp.com",
  projectId: "order-management-system-fc3bf",
  storageBucket: "order-management-system-fc3bf.appspot.com",
  messagingSenderId: "823208172721",
  appId: "1:823208172721:web:29b8919881539ef40b1690",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const storage = getStorage(app);
export default storage;
