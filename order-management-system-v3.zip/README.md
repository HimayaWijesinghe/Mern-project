# Install Node.js
https://nodejs.org/en/download/current

## Instructions to run the backend
```bash
cd backend
```

```bash
npm install
```

```bash
npm run dev
```

## Instructions to run the frontend
```bash
cd frontend
```

```bash
npm install
```

```bash
npm run dev
```

## Visit the following URL to see the application running
http://localhost:5173/

## Backend API
http://localhost:8000/

## Admin Credentials

Email: 

Password: 123456

---

# Test Credit Card Details

BRAND: Visa
NUMBER: 4242424242424242
CVC: Any 3 digits
DATE: Any future date

BRAND: Visa (debit)	
NUMBER: 4000056655665556
CVC: Any 3 digits
DATE: Any future date

BRAND: Mastercard
NUMBER: 5555555555554444
CVC: Any 3 digits
DATE: Any future date

BRAND: Mastercard (debit)	
NUMBER: 5200828282828210
CVC: Any 3 digits
DATE: Any future date